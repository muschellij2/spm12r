%-----------------------------------------------------------------------
% Job saved on 28-Apr-2015 23:00:44 by cfg_util (rev $Rev: 6134 $)
% spm SPM - SPM12 (6225)
% cfg_basicio BasicIO - Unknown
%-----------------------------------------------------------------------
matlabbatch{1}.spm.spatial.normalise.write.subj.def = {'%deformation%'};
matlabbatch{1}.spm.spatial.normalise.write.subj.resample = %resample%;
matlabbatch{1}.spm.spatial.normalise.write.woptions.bb = %bbox%
matlabbatch{1}.spm.spatial.normalise.write.woptions.vox = [2 2 2];
matlabbatch{1}.spm.spatial.normalise.write.woptions.interp = 4;
