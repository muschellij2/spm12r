%-----------------------------------------------------------------------
% Job saved on 28-Apr-2015 22:36:24 by cfg_util (rev $Rev: 6134 $)
% spm SPM - SPM12 (6225)
% cfg_basicio BasicIO - Unknown
%-----------------------------------------------------------------------
matlabbatch{1}.spm.spatial.smooth.data = {
                                          '%filename%'
                                          };
matlabbatch{1}.spm.spatial.smooth.fwhm = [%fwhm% %fwhm% %fwhm%];
matlabbatch{1}.spm.spatial.smooth.dtype = 0;
matlabbatch{1}.spm.spatial.smooth.im = 0;
matlabbatch{1}.spm.spatial.smooth.prefix = '%prefix%';
