%-----------------------------------------------------------------------
% Job saved on 29-Apr-2015 15:15:18 by cfg_util (rev $Rev: 6134 $)
% spm SPM - SPM12 (6225)
% cfg_basicio BasicIO - Unknown
%-----------------------------------------------------------------------
matlabbatch{1}.spm.temporal.st.scans = {
%filename%
};
matlabbatch{1}.spm.temporal.st.nslices = %nslices%;
matlabbatch{1}.spm.temporal.st.tr = %tr%;
matlabbatch{1}.spm.temporal.st.ta = %ta%;
matlabbatch{1}.spm.temporal.st.so = %sliceorder%;
matlabbatch{1}.spm.temporal.st.refslice = %refslice%;
matlabbatch{1}.spm.temporal.st.prefix = '%prefix%';
